function stuff(arr){
	for(var i=0;i<9;i++){
		console.log(i)
	}
}
stuff([1,2,3,4,5])