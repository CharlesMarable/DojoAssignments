from django.shortcuts import render, HttpResponse
from datetime import datetime

def index(request):
	return render (request, "first_app/index.html")

def methodfromurl(request):
	context = {
	"time" : datetime.datetime.now()
	}
	return render(request,'first_app/index.html', context)