//Problem 1:
var first_variable;
function firstFunc() {
  first_variable = "Not anymore!!!";
  console.log(first_variable);
}
first_variable = "Yipee I was first!";
console.log(first_variable);

//Problem 2:
var food;
function eat() {
  food = "half-chicken";
  console.log(food);
  food = "gone";
  console.log(food);
}
eat();
food = "Chicken";
console.log(food);

//Problem 3:
var new_word;
function lastFunc() {
  new_word = "old";
}
new_word = "blaaaaaaaaaaaaaah"
console.log(new_word);