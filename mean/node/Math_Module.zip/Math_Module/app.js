var math = require("./mathlib.js");
var mathstuff = new math();

var num1 = 20;
var num2 = 3;
var num = 6;
var max = 20;
var min = 10;
console.log("sum of num1 and num2 is", mathstuff.add(num1, num2));
